/**
* Author: Alok Aenugu
* Assignment: Platformer
* Date due: 2024-11-26, 11:59pm
* I pledge that I have completed this assignment without
* collaborating with anyone else, in conformance with the
* NYU School of Engineering Policies and Procedures on
* Academic Misconduct.
**/
#include "LevelB.h"
#include "Utility.h"

#define LEVEL_WIDTH 40
#define LEVEL_HEIGHT 8

constexpr char FONTSHEET_FILEPATH[] = "assets/font1.png",
           SPRITESHEET_FILEPATH[] = "assets/DK.png",
           ENEMY1_FILEPATH[]       = "assets/koopa.png",                                              //Created new enemy skins
           ENEMY2_FILEPATH[] = "assets/Mario_Tiles.png",
           ENEMY3_FILEPATH[] = "assets/george_0.png";

GLuint g_fontB_texture_id = 1;

unsigned int LEVELB_DATA[] =
{
    4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,
    4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0,
    4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    4, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
};

LevelB::~LevelB()
{
    delete [] m_game_state.enemies;
    delete    m_game_state.enemy1;
    delete    m_game_state.enemy1;
    delete    m_game_state.enemy1;
    delete    m_game_state.player;
    delete    m_game_state.map;
    Mix_FreeChunk(m_game_state.jump_sfx);
    Mix_FreeMusic(m_game_state.bgm);
}

void LevelB::initialise()
{
    GLuint map_texture_id = Utility::load_texture("assets/Mario_Tiles.png");
    m_game_state.map = new Map(LEVEL_WIDTH, LEVEL_HEIGHT, LEVELB_DATA, map_texture_id, 1.0f, 5, 1);
    
    GLuint player_texture_id = Utility::load_texture(SPRITESHEET_FILEPATH);

    int player_walking_animation[4][4] =
    {
        { 1, 5, 9, 13 },  // for George to move to the left,
        { 3, 7, 11, 15 }, // for George to move to the right,
        { 2, 6, 10, 14 }, // for George to move upwards,
        { 0, 4, 8, 12 }   // for George to move downwards
    };

    glm::vec3 acceleration = glm::vec3(0.0f, -4.81f, 0.0f);

    m_game_state.player = new Entity(
        player_texture_id,         // texture id
        5.0f,                      // speed
        acceleration,              // acceleration
        10.0f,                      // jumping power
        player_walking_animation,  // animation index sets
        0.0f,                      // animation time
        4,                         // animation frame amount
        0,                         // current animation index
        4,                         // animation column amount
        4,                         // animation row amount
        0.7f,                      // width
        0.7f,                       // height
        PLAYER
    );
    
    m_game_state.player->set_position(glm::vec3(5.0f, 0.0f, 0.0f));

    // Jumping
    m_game_state.player->set_jumping_power(5.5f);

    g_fontB_texture_id = Utility::load_texture(FONTSHEET_FILEPATH);
    
    /**
     Enemies' stuff */
    GLuint enemy1_texture_id = Utility::load_texture(ENEMY1_FILEPATH);
    GLuint enemy2_texture_id = Utility::load_texture(ENEMY2_FILEPATH);
    GLuint enemy3_texture_id = Utility::load_texture(ENEMY3_FILEPATH);

    m_game_state.enemies = new Entity[ENEMY_COUNT];


    //m_game_state.enemy1 = new Entity(enemy1_texture_id, 1.0f, 0.5f, 0.8f, ENEMY, GUARD, PATROLLING);
    //m_game_state.enemy1->set_position(glm::vec3(8.0f, 6.0f, 0.0f));
    //m_game_state.enemy1->set_movement(glm::vec3(0.0f));
    //m_game_state.enemy1->set_acceleration(glm::vec3(0.0f, -9.81f, 0.0f));

    //m_game_state.enemy2 = new Entity(enemy1_texture_id, 1.0f, 0.5f, 0.8f, ENEMY, GUARD, WALKING);
    //m_game_state.enemy2->set_position(glm::vec3(6.0f, 6.0f, 0.0f));
    //m_game_state.enemy2->set_movement(glm::vec3(0.0f));
    //m_game_state.enemy2->set_acceleration(glm::vec3(0.0f, -9.81f, 0.0f));

    //m_game_state.enemy3 = new Entity(enemy1_texture_id, 1.0f, 0.5f, 0.8f, ENEMY, GUARD, JUMPING);
    //m_game_state.enemy3->set_position(glm::vec3(4.0f, 6.0f, 0.0f));
    //m_game_state.enemy3->set_movement(glm::vec3(0.0f));
    //m_game_state.enemy3->set_acceleration(glm::vec3(0.0f, -9.81f, 0.0f));

    m_game_state.enemies[0] = Entity(enemy1_texture_id, 1.0f, 0.5f, 0.8f, ENEMY, GUARD, PATROLLING);
    m_game_state.enemies[0].set_position(glm::vec3(37.0f, -5.0f, 0.0f));
    m_game_state.enemies[0].set_movement(glm::vec3(0.0f));
    m_game_state.enemies[0].set_acceleration(glm::vec3(0.0f, -9.81f, 0.0f));

    m_game_state.enemies[1] = Entity(enemy1_texture_id, 1.0f, 0.5f, 0.8f, ENEMY, GUARD, WALKING);
    m_game_state.enemies[1].set_position(glm::vec3(3.0f, -4.0f, 0.0f));
    m_game_state.enemies[1].set_movement(glm::vec3(0.0f));
    m_game_state.enemies[1].set_acceleration(glm::vec3(0.0f, -9.81f, 0.0f));

    m_game_state.enemies[2] = Entity(enemy1_texture_id, 1.0f, 0.5f, 0.8f, ENEMY, GUARD, JUMPING);
    m_game_state.enemies[2].set_position(glm::vec3(37.0f, 3.0f, 0.0f));
    m_game_state.enemies[2].set_movement(glm::vec3(0.0f));
    m_game_state.enemies[2].set_acceleration(glm::vec3(0.0f, -9.81f, 0.0f));
    m_game_state.enemies[2].set_special(true);



    /**
     BGM and SFX
     */
    Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 4096);
    
    m_game_state.bgm = Mix_LoadMUS("assets/DK_CR.mp3");
    Mix_PlayMusic(m_game_state.bgm, -1);
    Mix_VolumeMusic(60.0f);
    
    m_game_state.jump_sfx = Mix_LoadWAV("assets/M_jump2.wav");
}

void LevelB::update(float delta_time)
{
    m_game_state.player->update(delta_time, m_game_state.player, m_game_state.enemies, ENEMY_COUNT, m_game_state.map);

    for (int i = 0; i < ENEMY_COUNT; i++)
    {
        m_game_state.enemies[i].update(delta_time, m_game_state.player, NULL, NULL, m_game_state.map);
    }

    if (m_game_state.player->get_position().x > 40.0f)
    {
        m_game_state.next_scene_id++;
    }
    if (m_game_state.player->get_position().y < -10.0f || !m_game_state.player->get_active())
    {
        m_game_state.deaths++;
        m_game_state.reset = true;
    }

    
    /*m_game_state.enemy1->update(delta_time, m_game_state.player, NULL, NULL, m_game_state.map);
    m_game_state.enemy2->update(delta_time, m_game_state.player, NULL, NULL, m_game_state.map);
    m_game_state.enemy3->update(delta_time, m_game_state.player, NULL, NULL, m_game_state.map);*/

}

void LevelB::render(ShaderProgram *g_shader_program)
{

    Utility::draw_text(g_shader_program, g_fontB_texture_id, "Lives: " + std::to_string(3 - m_game_state.deaths), 0.5f, 0.005f,
        glm::vec3(m_game_state.player->get_position().x, m_game_state.player->get_position().y + 2, 0));

    m_game_state.map->render(g_shader_program);

    for (int i = 0; i < ENEMY_COUNT; i++) {
        m_game_state.enemies[i].render(g_shader_program);
    }

    m_game_state.player->render(g_shader_program);
}
